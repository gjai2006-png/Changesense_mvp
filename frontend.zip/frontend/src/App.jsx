import React, { useMemo, useState } from "react";
import DocumentViewer from "./DocumentViewer";

const API_BASE = "http://localhost:8000";

function titleCaseTag(tag) {
  return tag
    .replace(/_/g, " ")
    .replace(/\b\w/g, (char) => char.toUpperCase());
}

function similarityClass(score) {
  if (score >= 95) return "good";
  if (score >= 85) return "warn";
  return "bad";
}

function StatBlock({ value, label }) {
  return (
    <div className="stat-block">
      <div className="stat-value">{value}</div>
      <div className="stat-label">{label}</div>
    </div>
  );
}

function ChangeCard({ change, type, onOpen, defaultOpen = false }) {
  const similarity = typeof change.similarity === "number" ? Math.round(change.similarity * 100) : null;
  const before = change.before || change.before_text || "";
  const after = change.after || change.after_text || "";
  const riskTags = change.risk_tags || [];

  return (
    <details className="change-card" open={defaultOpen}>
      <summary className="change-card-summary">
        <div>
          <div className="change-card-topline">
            <span className="change-id">{change.heading || "Change"}</span>
            <span className={`change-pill type-${type}`}>{type}</span>
            {similarity !== null && <span className={`change-pill similarity-${similarityClass(similarity)}`}>{similarity}%</span>}
          </div>
          <h4>{change.heading || "Change"}</h4>
        </div>
        <span className="change-expand">View</span>
      </summary>

      <div className="change-card-body">
        {riskTags.length > 0 && (
          <div className="risk-tags">
            {riskTags.map((tag) => (
              <span key={tag} className="risk-tag">
                {titleCaseTag(tag)}
              </span>
            ))}
          </div>
        )}

        {type === "integrity" && change.reason && <div className="integrity-note">{change.reason}</div>}

        <div className="change-diff-preview">
          <div>
            <div className="preview-label">Before</div>
            <pre className="preview-box before">{before || "Not present"}</pre>
          </div>
          <div>
            <div className="preview-label">After</div>
            <pre className="preview-box after">{after || "Not present"}</pre>
          </div>
        </div>

        <button className="btn btn-primary" onClick={() => onOpen(change, type)}>
          Open In Viewer
        </button>
      </div>
    </details>
  );
}

function EvidencePanel({ title, type, changes, onOpen }) {
  return (
    <section className="evidence-panel">
      <header>
        <h3>{title}</h3>
        <span>{changes.length}</span>
      </header>
      <div className="evidence-list">
        {changes.length === 0 ? (
          <div className="empty-line">No {title.toLowerCase()}.</div>
        ) : (
          changes.map((change, idx) => (
            <ChangeCard key={`${type}-${change.id}-${idx}`} change={change} type={type} onOpen={onOpen} />
          ))
        )}
      </div>
    </section>
  );
}

export default function App() {
  const [versionA, setVersionA] = useState(null);
  const [versionB, setVersionB] = useState(null);
  const [compare, setCompare] = useState(null);
  const [integrity, setIntegrity] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [viewerChange, setViewerChange] = useState(null);
  const [runId, setRunId] = useState(null);
  const [aiSummary, setAiSummary] = useState(null);

  const clauseMap = useMemo(() => {
    const map = new Map();
    if (!compare?.clauses) return map;

    compare.clauses.modified.forEach((clause) => map.set(clause.id, { ...clause, type: "modified" }));
    compare.clauses.added.forEach((clause) =>
      map.set(clause.id, {
        ...clause,
        before: "",
        after: clause.text,
        before_text: "",
        after_text: clause.text,
        type: "added",
      })
    );
    compare.clauses.deleted.forEach((clause) =>
      map.set(clause.id, {
        ...clause,
        before: clause.text,
        after: "",
        before_text: clause.text,
        after_text: "",
        type: "deleted",
      })
    );

    return map;
  }, [compare]);

  const confidence = useMemo(() => {
    if (!compare) return "Not Available";
    const density = compare.stats.modified_count > 0 ? compare.stats.high_risk_count / compare.stats.modified_count : 0;
    if (density <= 0.2) return "High";
    if (density <= 0.45) return "Medium";
    return "Review Required";
  }, [compare]);

  const highRiskChanges = useMemo(() => {
    if (!compare?.risks) return [];
    return compare.risks
      .filter((risk) => Array.isArray(risk.risk_tags) && risk.risk_tags.length > 0)
      .map((risk) => {
        const clause = clauseMap.get(risk.id);
        return {
          ...(clause || risk),
          id: risk.id,
          heading: risk.heading,
          risk_tags: risk.risk_tags,
          riskAnalysis: risk,
          type: clause?.type || "modified",
        };
      });
  }, [compare?.risks, clauseMap]);

  const integrityItems = useMemo(() => {
    if (!integrity?.integrity_alerts) return [];
    return integrity.integrity_alerts.map((item) => {
      const clause = clauseMap.get(item.id);
      return {
        ...(clause || item),
        ...item,
        type: clause?.type || "integrity",
      };
    });
  }, [integrity?.integrity_alerts, clauseMap]);

  const viewerSequence = useMemo(() => {
    const items = [];
    (compare?.clauses?.modified || []).forEach((change) => items.push({ change, type: "modified" }));
    (compare?.clauses?.added || []).forEach((change) => items.push({ change, type: "added" }));
    (compare?.clauses?.deleted || []).forEach((change) => items.push({ change, type: "deleted" }));
    integrityItems.forEach((change) => items.push({ change, type: "integrity" }));
    return items;
  }, [compare?.clauses, integrityItems]);

  const flattenClauseTree = (node, acc = {}) => {
    if (!node) return acc;
    if (node.clause_id && node.label && node.clause_id !== "root") {
      acc[node.clause_id] = node.label;
    }
    if (node.children) {
      node.children.forEach((child) => flattenClauseTree(child, acc));
    }
    return acc;
  };

  const runVerification = async () => {
    if (!versionA || !versionB) {
      setError("Upload both Version A and Version B first.");
      return;
    }

    setLoading(true);
    setError(null);
    setCompare(null);
    setIntegrity(null);
    setRunId(null);
    setAiSummary(null);

    try {
      const compareBody = new FormData();
      compareBody.append("version_a", versionA);
      compareBody.append("version_b", versionB);

      const compareRes = await fetch(`${API_BASE}/compare`, { method: "POST", body: compareBody });
      if (!compareRes.ok) throw new Error("Clause verification failed.");

      const compareJson = await compareRes.json();
      
      // Transform backend response to frontend expected structure
      const transformedCompare = transformBackendResponse(compareJson);
      
      setRunId(compareJson.run?.run_id || null);

      // Extract integrity alerts
      const integrityJson = {
        integrity_alerts: compareJson.integrity_alerts || [],
      };

      setCompare(transformedCompare);
      setIntegrity(integrityJson);

      if (compareJson.run?.run_id) {
        const aiRes = await fetch(
          `${API_BASE}/ai/insights?run_id=${encodeURIComponent(compareJson.run.run_id)}&ai_enabled=true`,
          { method: "POST" }
        );
        const aiJson = await aiRes.json();
        if (aiJson?.raw_text) {
          try {
            const parsed = JSON.parse(aiJson.raw_text);
            setAiSummary({ ...parsed, ai_enabled: true });
          } catch (e) {
            setAiSummary({ error: "AI returned non-JSON output. Please retry." });
          }
        } else {
          setAiSummary(aiJson);
        }
      }
    } catch (runError) {
      setError(runError.message || "Verification failed.");
    } finally {
      setLoading(false);
    }
  };

  const transformBackendResponse = (backendResponse) => {
    const { changes = [], materiality = [], clause_tree_b } = backendResponse;
    const clauseLabels = flattenClauseTree(clause_tree_b?.root);
    
    // Group changes by type
    const modified = [];
    const added = [];
    const deleted = [];
    
    changes.forEach((change) => {
      const transformedChange = {
        id: change.clause_id,
        clause_id: change.clause_id,
        heading: change.heading || clauseLabels[change.clause_id] || "Change",
        before: change.before_text || "",
        after: change.after_text || "",
        before_text: change.before_text || "",
        after_text: change.after_text || "",
        word_diffs: change.word_diffs || null,
        similarity: 1.0, // Default similarity
        risk_tags: [],
      };
      
      // Determine if added, deleted, or modified
      if (!change.before_text || change.before_text.trim() === "") {
        added.push(transformedChange);
      } else if (!change.after_text || change.after_text.trim() === "") {
        deleted.push(transformedChange);
      } else {
        modified.push(transformedChange);
      }
    });
    
    // Aggregate materiality findings by clause so one clause renders as one card with multiple tags.
    const riskByClause = new Map();
    materiality.forEach((finding) => {
      const key = finding.clause_id || "__unknown__";
      const existing = riskByClause.get(key);
      if (!existing) {
        riskByClause.set(key, {
          id: key,
          clause_id: key,
          heading: clauseLabels[key] || "Change",
          risk_tags: finding.category ? [finding.category] : [],
          before_text: "",
          after_text: "",
          findings: [finding],
        });
        return;
      }

      if (finding.category && !existing.risk_tags.includes(finding.category)) {
        existing.risk_tags.push(finding.category);
      }
      existing.findings.push(finding);
    });

    const risks = Array.from(riskByClause.values());
    
    // Calculate stats
    const stats = {
      modified_count: modified.length,
      added_count: added.length,
      deleted_count: deleted.length,
      high_risk_count: risks.length,
      obligation_shift_count: risks.filter((r) =>
        (r.risk_tags || []).some((tag) => /obligation/i.test(String(tag)))
      ).length,
    };
    
    return {
      clauses: {
        modified,
        added,
        deleted,
      },
      risks,
      stats,
    };
  };

  const openViewer = (change, type) => {
    const changeId = change.clause_id || change.id;
    const base = clauseMap.get(changeId) || { ...change, type };
    const riskAnalysis = compare?.risks?.find((risk) => risk.id === change.id);

    setViewerChange({
      ...base,
      ...change,
      id: changeId,
      clause_id: changeId,
      type: base.type || type,
      risk_tags: riskAnalysis?.risk_tags || base.risk_tags || change.risk_tags || [],
      riskAnalysis: riskAnalysis || base.riskAnalysis,
      before: change.before ?? base.before ?? base.before_text ?? "",
      after: change.after ?? base.after ?? base.after_text ?? "",
      before_text: change.before ?? base.before ?? base.before_text ?? "",
      after_text: change.after ?? base.after ?? base.after_text ?? "",
    });
  };

  const viewerSequenceKey = (item) => `${item?.type || "modified"}::${item?.clause_id || item?.id || ""}`;

  const currentViewerIndex = useMemo(() => {
    if (!viewerChange) return -1;
    const key = viewerSequenceKey(viewerChange);
    return viewerSequence.findIndex(({ change, type }) => viewerSequenceKey({ ...change, type }) === key);
  }, [viewerChange, viewerSequence]);

  const openViewerAtIndex = (index) => {
    const target = viewerSequence[index];
    if (!target) return;
    openViewer(target.change, target.type);
  };

  const showLanding = !compare && !loading;

  return (
    <div className="app">
      {showLanding && (
        <section className="landing">
          <div className="landing-content">
            <div className="kicker">ChangeSense</div>
            <h1>Change Verification</h1>
            <p>Deterministic structural comparison for high-stakes documents.</p>
          </div>

          <div className="upload-sheet">
            <div className="upload-grid">
              <label>
                <span>Version A</span>
                <div className="file-picker">
                  <span className="file-picker-btn">Choose File</span>
                  <span className="file-picker-name">{versionA?.name || "No file selected"}</span>
                </div>
                <input
                  className="file-input-hidden"
                  type="file"
                  accept=".txt,.docx,.pdf"
                  onChange={(e) => setVersionA(e.target.files?.[0] || null)}
                />
              </label>
              <label>
                <span>Version B</span>
                <div className="file-picker">
                  <span className="file-picker-btn">Choose File</span>
                  <span className="file-picker-name">{versionB?.name || "No file selected"}</span>
                </div>
                <input
                  className="file-input-hidden"
                  type="file"
                  accept=".txt,.docx,.pdf"
                  onChange={(e) => setVersionB(e.target.files?.[0] || null)}
                />
              </label>
            </div>
            <button className="btn btn-primary large" onClick={runVerification} disabled={loading}>
              {loading ? "Running..." : "Run Change Verification"}
            </button>
          </div>
        </section>
      )}

      {(compare || loading) && (
        <section className="topbar">
          <div className="upload-grid compact">
            <label>
              <span>Version A</span>
              <div className="file-picker">
                <span className="file-picker-btn">Choose File</span>
                <span className="file-picker-name">{versionA?.name || "No file selected"}</span>
              </div>
              <input
                className="file-input-hidden"
                type="file"
                accept=".txt,.docx,.pdf"
                onChange={(e) => setVersionA(e.target.files?.[0] || null)}
              />
            </label>
            <label>
              <span>Version B</span>
              <div className="file-picker">
                <span className="file-picker-btn">Choose File</span>
                <span className="file-picker-name">{versionB?.name || "No file selected"}</span>
              </div>
              <input
                className="file-input-hidden"
                type="file"
                accept=".txt,.docx,.pdf"
                onChange={(e) => setVersionB(e.target.files?.[0] || null)}
              />
            </label>
          </div>
          <button className="btn btn-primary" onClick={runVerification} disabled={loading}>
            {loading ? "Running..." : "Run Change Verification"}
          </button>
          <div className="run-meta">
            <span className={`status ${compare ? "done" : "idle"}`}>{compare ? "Complete" : "Idle"}</span>
            <span className="confidence">Confidence: {confidence}</span>
          </div>
        </section>
      )}

      {error && <div className="error">{error}</div>}
      {loading && <div className="loading">Analyzing changes and integrity signals...</div>}

      {compare && (
        <>
          <section className="overview">
            <article className="high-risk">
              <header>
                <h2>High-Risk Changes</h2>
                <span>{compare.stats.high_risk_count}</span>
              </header>

              <div className="high-risk-body">
                {highRiskChanges.length === 0 ? (
                  <div className="empty-line">No high-risk changes detected.</div>
                ) : (
                  highRiskChanges.map((change, idx) => (
                    <ChangeCard
                      key={`high-${change.id}-${idx}`}
                      change={change}
                      type={change.type || "modified"}
                      onOpen={openViewer}
                      defaultOpen={idx === 0}
                    />
                  ))
                )}
              </div>
            </article>

            <aside className="summary">
              <h3>Verification Summary</h3>
              <div className="summary-stats">
                <StatBlock value={compare.stats.modified_count} label="Modified" />
                <StatBlock value={compare.stats.added_count} label="Added" />
                <StatBlock value={compare.stats.deleted_count} label="Deleted" />
                <StatBlock value={compare.stats.high_risk_count} label="High Risk" />
                <StatBlock value={compare.stats.obligation_shift_count} label="Obligation Shifts" />
              </div>
              <button
                className="btn btn-ghost"
                onClick={() => runId && window.open(`${API_BASE}/report?run_id=${encodeURIComponent(runId)}`, "_blank")}
              >
                Export PDF Report
              </button>
            </aside>
          </section>

          <section className="evidence">
            <EvidencePanel title="Modified" type="modified" changes={compare.clauses.modified} onOpen={openViewer} />
            <EvidencePanel title="Added" type="added" changes={compare.clauses.added} onOpen={openViewer} />
            <EvidencePanel title="Deleted" type="deleted" changes={compare.clauses.deleted} onOpen={openViewer} />
            <EvidencePanel title="Integrity" type="integrity" changes={integrityItems} onOpen={openViewer} />
          </section>

          <section className="ai-summary">
            <header>
              <h2>AI Final Report</h2>
            </header>
            {!aiSummary && <div className="empty-line">Run verification to see AI insights.</div>}
            {aiSummary?.error && <div className="empty-line">{aiSummary.error}</div>}
            {aiSummary && !aiSummary.error && aiSummary?.summaries?.length === 0 && (
              <div className="empty-line">No AI summary returned.</div>
            )}
            {aiSummary?.summaries?.length > 0 && (
              <div className="ai-summary-grid">
                {aiSummary.summaries.map((summary, idx) => (
                  <article key={`ai-${idx}`} className="ai-report-card">
                    <div className="ai-report-card-top">
                      <span className="ai-report-kind">{String(summary.type || "summary").replace(/_/g, " ")}</span>
                      <span className="ai-report-count">{summary.bullets?.length || 0} points</span>
                    </div>
                    <h4>{String(summary.type || "Summary").replace(/\b\w/g, (c) => c.toUpperCase())}</h4>
                    <ul className="ai-report-bullets">
                      {(summary.bullets || []).map((bullet, i) => (
                        <li key={`${idx}-${i}`}>{bullet}</li>
                      ))}
                    </ul>
                    {Array.isArray(summary.backing_change_ids) && summary.backing_change_ids.length > 0 && (
                      <div className="ai-report-foot">
                        Backed by: {summary.backing_change_ids.slice(0, 4).join(", ")}
                        {summary.backing_change_ids.length > 4 ? " ..." : ""}
                      </div>
                    )}
                  </article>
                ))}
              </div>
            )}
          </section>
        </>
      )}

      {viewerChange && (
        <DocumentViewer
          change={viewerChange}
          aiSummary={aiSummary}
          onClose={() => setViewerChange(null)}
          onPrev={currentViewerIndex > 0 ? () => openViewerAtIndex(currentViewerIndex - 1) : null}
          onNext={
            currentViewerIndex >= 0 && currentViewerIndex < viewerSequence.length - 1
              ? () => openViewerAtIndex(currentViewerIndex + 1)
              : null
          }
          canPrev={currentViewerIndex > 0}
          canNext={currentViewerIndex >= 0 && currentViewerIndex < viewerSequence.length - 1}
        />
      )}
    </div>
  );
}
